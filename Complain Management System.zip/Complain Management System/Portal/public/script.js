// let a = alert("Application Submitted Sucessfully");
// let h = document.querySelector("h");
// button.addEventListner('click',()=>{

// })