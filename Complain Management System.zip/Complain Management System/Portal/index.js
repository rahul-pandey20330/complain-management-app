//require express
const express = require("express");
const app = express();//insert all express toll in app variable
//database connection
const mysql = require("mysql2");
const connection = mysql.createConnection({
    host     : 'localhost',
    user     : 'root',
    password : 'NRP20330',
    database : 'Portal'
  });
try{
connection.query('show tables', (error, results)=> {
    if (error) throw error;
    console.log(results);
});
}
catch(error){
    console.log(error);
}

Port = 3000;//localhost port where your data gone

app.set("view engine",'ejs');//set views engen for rendering html and css pages
const path = require('path');
app.set('views',path.join(__dirname,'/views'));
app.use(express.json());
app.use(express.urlencoded({extended : true}));

//link css file
app.use(express.static("public"));

//create rout using get method (Data server se send krne ke liye)
app.get('/',(req,res)=>{
    res.render("Index.ejs")
});

let q ="INSERT INTO complaints (username, course, email, roll_no, mobile_no, department, faculty_name, faculty_email, complaint_title, complaint_text)VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

// let complaints = 'select * from complaints';

//create rout using post method (Data server pe retrive krne ke liye)
app.post('/submit-complain-form',(req,res)=>{
    res.render('index.ejs');

    const {
        username, course, 
        email, roll_no,
         mobile_no, 
         department, 
         faculty_name, 
         faculty_email, 
         complaint_title, 
         complaint_text
    }  = req.body;
    

    const query = q;

    const values = [
        username, 
        course, 
        email, 
        roll_no,
        mobile_no, 
        department, 
        faculty_name, 
        faculty_email, 
        complaint_title, 
        complaint_text
    ];

    try{
        connection.query(query,values, (error,results)=> {
            if (error) throw error;
            console.log('Data inserted successfully:', results);
            console.log('Complaint Submeted Sucessfully');
        });
        }
        catch(error){
            console.log('Error inserting data:', error);
        }
})
//call server
app.listen(Port,()=>{
    console.log(`App is Running on Port ${Port} `);
})
app.get('/complaints',(req,res)=>{
    let q = 'select * from complaints';
    try{
        connection.query(q, (error, results)=> {
            if (error) throw error;
            // console.log(results); 
            // res.send(results);
             res.render('complaintsdata.ejs',{complaints : results});
            
        });
        }
        catch(error){
            console.log(error);
        }

})
